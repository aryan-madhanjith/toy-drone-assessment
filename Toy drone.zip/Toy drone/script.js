// Functions for the game itself

const directions = ["NORTH", "EAST", "SOUTH", "WEST"];

class Drone
{
    constructor()
    {
        this.element = document.getElementById("img-drone");
        this.x = -1;
        this.y = -1;
        this.direction = 0;
    }

    update_position(x, y)
    {
        this.x = x;
        this.y = y;
        const grid_tile = document.getElementById(x + "," + y);
        grid_tile.appendChild(this.element);
    }

    place(x, y, direction)
    {
        this.direction = parseInt(direction);
        this.update_position(x, y);
        this.rotate_drone();
    }

    move()
    {
        let on_edge = false;
        switch(this.direction)
        {
            case 0:
                if (this.x == 9){ on_edge = true; }
                else {this.x++};
                break;
            case 1:
                if (this.y == 9){ on_edge = true; }
                else {this.y++};
                break;
            case 2:
                if (this.x == 0){ on_edge = true; }
                else {this.x--};
                break;
            case 3:
                if (this.y == 0){ on_edge = true; }
                else {this.y--};
                break;
        }
        if (on_edge)
        {
            disable_btn("btn-move", "Drone is not able to move any more units " + directions[this.direction] + ". Try using LEFT or RIGHT to change direction, and MOVE again.");
        }
        else
        {
            this.update_position(this.x, this.y);
        }
    }

    rotate_drone()
    {
        var angle = this.direction * 90;
        this.element.style.transform = `translate(-50%, -50%) rotate(${angle}deg)`;
    }

    left()
    {
        if (document.getElementById("btn-move").disabled)
        { 
            enable_btn("btn-move", "Click to move drone one unit " + directions[this.direction] + "."); 
        }
        if (this.direction == 0) { this.direction = 3; }
        else { this.direction -= 1; }
        this.rotate_drone();
    }

    right()
    {
        if (document.getElementById("btn-move").disabled)
        { 
            enable_btn("btn-move", "Click to move drone one unit " + directions[this.direction] + "."); 
        }
        if (this.direction == 3){this.direction = 0;}
        else {this.direction += 1;}
        this.rotate_drone();
    }

    report()
    {
        alert("x : " + this.x + ", Y : " + this.y + ", facing : " + directions[this.direction]);
    }
}


function disable_btn(btn_id, tooltip="")
{
    const btn = document.getElementById(btn_id);
    btn.setAttribute("disabled", "");
    btn.setAttribute("title", tooltip);
    btn.style.color = 'grey';
}

function enable_btn(btn_id, tooltip="")
{
    const btn = document.getElementById(btn_id);
    btn.removeAttribute("disabled");
    btn.setAttribute("title", tooltip);
}


// Functions for elements of the html page


function create_grid_items()
{
    const grid = document.getElementById("grid");
    for (let row=9; row>=0; row--)  // HTML adds rows below the current one, hence, to have 0,0 as the bottom left, start with the top row
    {
        for (let column=0; column<10; column++)
        {
            const grid_tile = document.createElement('div');
            grid_tile.id = row + "," + column;
            grid_tile.classList.add("grid-item");
            grid.appendChild(grid_tile);
        }
    }
}

create_grid_items();

const drone = new Drone();

const btn_place = document.getElementById("btn-place");
btn_place.addEventListener("click", function()
{
    modal.style.display = 'block';
});
const modal =  document.getElementById('modal-place-overlay');
const btn_place_confirm = document.getElementById("btn-place-confirm");
btn_place_confirm.addEventListener("click", function()
{
    const edt_place_x = document.getElementById("edt-place-x");
    const edt_place_y = document.getElementById("edt-place-y");
    const edt_place_direction = document.getElementById("edt-place-direction");
    drone.element.style.display = 'block';
    drone.place(parseInt(edt_place_x.value), parseInt(edt_place_y.value), parseInt(edt_place_direction.value));
    modal.style.display = 'None';

    enable_btn("btn-move", "Click to move drone one unit forward.")
    enable_btn("btn-left", "Click to turn drone left.")
    enable_btn("btn-right", "Click to turn drone right.")
    enable_btn("btn-report", "Click to view the drone's (x,y) co-ordinates and cardinal direction.")
    enable_btn("btn-attack", "Click to fire a projectile 2 squares ahead.")
});
const btn_place_cancel = document.getElementById("btn-place-cancel");
btn_place_cancel.addEventListener("click", function()
{
    modal.style.display = 'None';
});

const btn_move = document.getElementById("btn-move");
btn_move.addEventListener("click", function()
{
    drone.move();
});

const btn_left = document.getElementById("btn-left");
btn_left.addEventListener("click", function(){ drone.left(); })

const btn_right = document.getElementById("btn-right");
btn_right.addEventListener("click", function(){ drone.right(); })

const btn_report = document.getElementById("btn-report");
btn_report.addEventListener('click', function(){ drone.report(); })

const btn_attack = document.getElementById("btn-attack");
btn_attack.addEventListener('click', function()
{
    let target_x = drone.x; 
    let target_y = drone.y;

    switch(drone.direction)
    {
        case 0:
            target_x += 2;
            break;
        case 1:
            target_y += 2;
            break;
        case 2:
            target_x -= 2;
            break;
        case 3:
            target_y -= 2;
            break;
    }

    if ((target_x < 0) || (target_x > 9) || (target_y < 0) || (target_y > 9))
    {
        alert("Drone cannot attack outside the grid.")
    }
    else
    {
    // Move projectile to target
    const projectile = document.createElement("div");
    projectile.classList.add("projectile");

    const start_tile = document.getElementById(drone.x + "," + drone.y);
    start_tile.appendChild(projectile);

    let grid_tile = null;
    var i = 0;

    var projectileInterval = setInterval(function () {
        // Add your logic here based on grid_tile
        switch(drone.direction)
        {
            case 0:
                i += 1;
                grid_tile = document.getElementById((drone.x + i) + "," + drone.y);
                grid_tile.appendChild(projectile);
                break;
            case 1:
                i += 1;
                grid_tile = document.getElementById(drone.x + "," + (drone.y + 1));
                grid_tile.appendChild(projectile);
                break;
            case 2:
                i -= 1;
                grid_tile = document.getElementById((drone.x - 1) + "," + drone.y);
                grid_tile.appendChild(projectile);
                break;
            case 3:
                i -= 1;
                grid_tile = document.getElementById(drone.x + "," + (drone.y - 1));
                grid_tile.appendChild(projectile);
                break;
        }

        // Check if you want to stop the interval after a certain condition
        if (Math.abs(i) == 2) 
        {
            clearInterval(projectileInterval);
            grid_tile.removeChild(projectile);
            const target_tile = document.getElementById(target_x + "," + target_y);
            const target = document.createElement("div");

            target_tile.appendChild(target);
            target.classList.add("target-item");
            setTimeout(function(){ 
                target_tile.classList.remove("target-item");
                target_tile.removeChild(target);
            }, 4000);
        }
    }, 500);
}

});

// Only valid command at start is PLACE
disable_btn("btn-move", "Please click PLACE to get put drone on the grid.")
disable_btn("btn-left", "Please click PLACE to get put drone on the grid.")
disable_btn("btn-right", "Please click PLACE to get put drone on the grid.")
disable_btn("btn-report", "Please click PLACE to get put drone on the grid.")
disable_btn("btn-attack", "Please click PLACE to get put drone on the grid.")
